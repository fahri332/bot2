const ownermenu = (prefix) => { 
	return ` 
	
╭──「 *OWNER ONLY* 」───
│
├➲ *${prefix}addprem [mentioned]*
├➲ *${prefix}removeprem [mention]*
├➲ *${prefix}setppbot*
├➲ *${prefix}setreply*
├➲ *${prefix}bc*
├➲ *${prefix}bcgc*
├➲ *${prefix}ban*
├➲ *${prefix}unban*
├➲ *${prefix}block*
├➲ *${prefix}unblock*
├➲ *${prefix}clearall*
├➲ *${prefix}delete*
├➲ *${prefix}clone*
├➲ *${prefix}getses*
├➲ *${prefix}leave*
│
╰──────────────────
	
            *©explors*`
	}
exports.ownermenu = ownermenu