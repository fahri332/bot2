const nsfwmenu = (prefix) => { 
	return ` 
╭─────「 *NSFW MENU* 」───
│
├➲ *${prefix}playmp3 [dj I am lady]*
├➲ *${prefix}fb [link video]*
├➲ *${prefix}snack [link snack video]*
├➲ *${prefix}ytmp3 [link yt]*
├➲ *${prefix}ytmp4 [link yt]*
├➲ *${prefix}joox [Monolog Pamungkas]*
├➲ *${prefix}smule [Link Video Smule]*
├➲ *${prefix}cersex*
├➲ *${prefix}asupan*
├➲ *${prefix}xxx [japan]*
├➲ *${prefix}pornhub [stepMoms]*
├➲ *${prefix}hentai [Random]*
├➲ *${prefix}ban [TagUser]*
├➲ *${prefix}unban [TagUser]*
├➲ *${prefix}bc [teks]*
├➲ *${prefix}asupan*
│
╰────────────────────

	            *©explors*`
	}
exports.nsfwmenu = nsfwmenu